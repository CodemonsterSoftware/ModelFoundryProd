﻿print("hello world")
